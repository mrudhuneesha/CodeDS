void reverse_list(list_node *head){
    list_node *
}
